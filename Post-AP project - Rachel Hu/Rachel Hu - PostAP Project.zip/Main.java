/**
 * Main class for running the program
 * Instructions for how to use the program are in the README.TXT file
 *
 * @author Rachel Hu
 * @version v1.06.03 (June 8, 2021)
 */

public class Main
{
    public static void main(String[] args)
    {
        new ArtWindow();
    }
}